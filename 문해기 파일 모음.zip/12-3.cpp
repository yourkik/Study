//#include<stdio.h>
//#include<stdlib.h>
//#define _CRT_SECURE_NO_WARNINGS
//
//struct NODE {
//	int key;
//	struct NODE* next;
//};
//
//int main() {
//	struct NODE* node;
//	node = (NODE*)malloc(sizeof(NODE));
//	if (node != (NODE*)NULL) {
//		(*node).key = 100;
//		(*node).next = NULL;
//		printf("%d\n", node->key);
//	}
//	free(node);
//	return 0;
//}