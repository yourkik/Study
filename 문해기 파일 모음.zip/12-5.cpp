//#define _crt_secure_no_warnings
//#include<stdio.h>
//#include<stdlib.h>
//
//struct NODE {
//	int key;
//	struct NODE* next;
//};
//
//struct NODE* createNewNode(int k) {
//	struct NODE* newNode = (NODE*)malloc(sizeof(NODE));
//	newNode->key = k;
//	newNode->next = NULL;
//	return newNode;
//}
//
//int main() {
//	NODE* node0, * node1, * node2;
//	node0 = createNewNode(100);
//	node1 = createNewNode(200);
//	node2 = createNewNode(467);
//	node0->next = node1;
//	node1->next = node2;
//	printf("%d\n", node0->key);//�迭ó�� ��� ����
//	printf("%d %d\n", node1->key, node0->next->key);
//	printf("%d %d %d", node2->key, node1->next->key, node0->next->next->key);
//	free(node0);
//	free(node1);
//	free(node2);
//}