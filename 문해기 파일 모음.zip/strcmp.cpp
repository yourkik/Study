//#define _CRT_SECURE_NO_WARNINGS
//#include<stdio.h>
//#include<string.h>
//
//
//int main() {
//	char s[] = "I wanna be the best guy";
//	char k[30];
//	strcpy(k,s);
//	if (strcmp(k,"I wanna be the best guy")==0) {
//		printf("same");
//	}
//	else {
//		printf("different");
//	}
//	return 0;
//}