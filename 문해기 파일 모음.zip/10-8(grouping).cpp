//#define _CRT_SECURE_NO_WARNINGS
//#include <stdio.h>
//#include <string.h>
//
//struct PERSON {
//    char name[20];
//    int age;
//    char hobby[20];
//};
//void swap(struct PERSON* a, struct PERSON* b) {
//    struct PERSON tmp = *a;
//    *a = *b;
//    *b = tmp;
//}
//void sort_by_age(struct PERSON* a, int n) {
//    int i, j;
//
//    for (i = 0; i < n - 1; i++) {
//        for (j = n - 1; j > i; j--) {
//            if (a[j - 1].age > a[j].age)
//                swap(&a[j - 1], &a[j]);
//        }
//    }
//}
//void sort_by_name(struct PERSON* a, int n) {
//    int i, j;
//    for (i = 0; i < n - 1; i++) {
//        for (j = n - 1; j > i; j--) {
//            if (strcmp(a[j - 1].name, a[j].name) > 0)
//                swap(&a[j - 1], &a[j]);
//        }
//    }
//}
//void sort_by_hobby(struct PERSON* a, int n) {
//    int i, j;
//    for (i = 0; i < n - 1; i++) {
//        for (j = n - 1; j > i; j--) {
//            if (strcmp(a[j - 1].hobby, a[j].hobby) > 0)
//                swap(&a[j - 1], &a[j]);
//        }
//    }
//}
//int main() {
//	FILE* f;
//	struct PERSON pn[6];
//	f = fopen("personal.txt", "r");
//    int i;
//    for (i = 0;i < 6;i++) {
//        fscanf(f, "%s %d %s", &pn[i].name, &pn[i].age, &pn[i].hobby);
//    }
//    sort_by_age(pn, 6);
//    printf("Sort by age :\n");
//    for (i = 0;i < 6;i++) {
//        printf("%s %d %s\n", pn[i].name, pn[i].age, pn[i].hobby);
//    }
//
//    sort_by_hobby(pn, 6);
//    printf("\nSort by hobby :\n");
//    for (i = 0;i < 6;i++) {
//        printf("%s %d %s\n", pn[i].name, pn[i].age, pn[i].hobby);
//    }
//    printf("\n");
//
//    sort_by_name(pn, 6);
//    printf("Sort by name :\n");
//    for (i = 0;i < 6;i++) {
//        printf("%s %d %s\n", pn[i].name, pn[i].age, pn[i].hobby);
//    }
//    fclose(f);
//    return 0;
//}