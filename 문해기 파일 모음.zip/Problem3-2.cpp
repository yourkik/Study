//#define _CRT_SECURE_NO_WARNINGS
//#include <stdio.h>
//
//void main()
//{
//    int i;
//    char ch;
//    char Inname[20];
//    char Outname[20];
//    FILE* myInFile,*myOutFile;
//    printf("Enter InFile name ");
//    scanf("%s", Inname);
//    getchar();
//    printf("Enter OutFIle name ");
//    scanf("%s", Outname);
//    myInFile = fopen(Inname, "r");
//    myOutFile = fopen(Outname, "w");
//    while ((ch = fgetc(myInFile)) != EOF) {
//        fputc(ch,myOutFile);
//   }
//    fclose(myInFile);
//    fclose(myOutFile);
//}
