//#define _CRT_SECURE_NO_WARNINGS
//#include<stdio.h>
//#include<stdlib.h>
//
//int main() {
//	int* nums, i;
//	nums = (int*)malloc(10 * sizeof(int));
//	for (i = 0;i < 10;i++) {
//		printf("Enter integer : ");
//		scanf("%d", &nums[i]);
//		printf("Result : %d", nums[i]);
//	}
//	free(nums);
//	return 0;
//}