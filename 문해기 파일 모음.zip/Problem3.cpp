//#define _CRT_SECURE_NO_WARNINGS
//#include <stdio.h>
//#define MAX 5
//struct EMP {
//    char name[20];
//    char position[20];
//    int id;
//    float years;
//    char birthday[20];
//};
//void main()
//{
//    int i;
//    FILE* myFile;
//    struct EMP employee[5];
//    employee[0] = { "Anthony","A.J", 10031, 7.82, "12/18/62" };
//    employee[1] = { "Burrows","W.K.",10067, 9.14, "6/9/63" };
//    employee[2] = { "Fain","B.D",10083, 8.79, "5/18/59" };
//    employee[3] = { "Janney","P.",10095, 10.57, "9/28/62" };
//    employee[4] = { "Smith","G.J",10105, 8.50, "12/20/61" };
//    myFile = fopen("employee.txt", "w");
//    if (myFile == NULL)
//        printf("\nFile Could Not Be Opened");
//    else
//    {
//        for (i = 0; i < MAX; i = i + 1)
//            fprintf(myFile, "%7s %7s %7d %7f %7s%\n", employee[i].name, employee[i].position, employee[i].id, employee[i].years, employee[i].birthday);
//        fclose(myFile);
//    }
//}
