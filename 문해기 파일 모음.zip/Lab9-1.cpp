//#define _CRT_SECURE_NO_WARNINGS
//#include<stdio.h>
//
//
//struct EMP {
//	int RPN;
//	char name[20];
//	float salary;
//	float bonus;
//};
//
//int check_prev(struct EMP *arr,EMP emp, int count){
//	for (int i = 0;i < count;i++) {
//		if (arr[i].RPN == emp.RPN)return 1;
//	}
//	return 0;
//};
//
//int main() {
//	struct EMP employee[100];
//	int total_num=0,register_num=0;
//	printf("Type the number of emplyees : ");
//	scanf("%d", &total_num);
//
//	for (int i = 0;i < total_num;i++) {
//		struct EMP tmp;
//		printf("\n Type employee information(RPN, name, salary, bonus) : ");
//		scanf("%d %s %f %f", &tmp.RPN, &tmp.name, &tmp.salary, &tmp.bonus);
//		if (check_prev(employee,tmp,register_num)) {
//			printf("Error : the RPN is already registered\n\n");
//		}
//		else if (tmp.bonus > tmp.salary) {
//			printf("Error : the bonus must be less than salary\n\n");
//		}
//		else {
//			printf("The employee has been registered\n\n");
//			employee[register_num] = tmp;
//			register_num++;
//		}
//	}
//	for (int i = 0;i < register_num;i++) {
//		printf("%d-th employee : RPN : %d Name : %s Salary : %f bonus : %f\n", i, employee[i].RPN, employee[i].name, employee[i].salary, employee[i].bonus);
//	}
//}