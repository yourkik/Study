//#define _CRT_SECURE_NO_WARNINGS
//#include<stdio.h>
//#include<stdlib.h>
//
//struct NODE {
//	int key;
//	struct NODE* next;
//};
//
//int main() {
//	NODE* node0, * node1, * node2;
//	node0 = (NODE*)malloc(sizeof(NODE));
//	node1 = (NODE*)malloc(sizeof(NODE));
//	node2 = (NODE*)malloc(sizeof(NODE));
//	node0->next = node1;
//	node1->next = node2;
//	node2->next = NULL;
//	node0->key = 100;
//	node1->key = 200;
//	node2->key = 300;
//	printf("%d\n", node0->key);//�迭ó�� ��� ����
//	printf("%d %d\n", node1->key, node0->next->key);
//	printf("%d %d %d", node2->key, node1->next->key, node0->next->next->key);
//}