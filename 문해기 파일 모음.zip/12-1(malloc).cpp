//#include<stdlib.h>
//#include<stdio.h>
//
//struct NODE {
//	int key;
//	struct NODE* next;
//};
//int main() {
//	struct NODE* nums;
//	nums = (NODE*)malloc(10 * sizeof(NODE));
//	if (nums == (NODE*)NULL) {
//		printf("malloc failed");
//		exit(1);
//	}
//	free(nums);
//	return 0;
//}