//#define _CRT_SECURE_NO_WARNINGS
//#include<stdio.h>
//
//struct CAR {
//	char name[20];
//	int year;
//};
//int main() {
//	FILE* f;
//	f = fopen("cars.txt", "w");
//	CAR c[2] = { {"Avante", 2007},{"Sonata",2008} };
//	for (int i = 0;i < 2;i++) {
//		fprintf(f, "%s %d\n", c[i].name, c[i].year);
//	}
//	fclose(f);
//
//	f = fopen("cars.txt", "r");
//	char car_tmp[20];
//	int year_tmp;
//	for (int i = 0;i < 2;i++) {
//		fscanf(f, "%s %d", &car_tmp, &year_tmp);
//		printf("%s %d\n", car_tmp, year_tmp);
//	}
//	fclose(f);
//}