//#define _CRT_SECURE_NO_WARNINGS
//#include<stdio.h>
//
//struct CAR {
//	char name[20];
//	int year;
//	float price;
//};
//int main() {
//	FILE* f;
//	f = fopen("cars.txt", "w");
//	CAR c[4] = { {"Avante", 2007,13000},{"Sonata",2008,18000},{"SM7",2009,22000},{"Equus",2010,35000} };
//	for (int i = 0;i < 4;i++) {
//		fprintf(f, "%s %d %.2f\n", c[i].name, c[i].year,c[i].price);
//	}
//	fclose(f);
//
//	f = fopen("cars.txt", "r");
//	char car_tmp[20];
//	int year_tmp;
//	float price_tmp;
//	for (int i = 0;i < 4;i++) {
//		fscanf(f, "%s %d %f", &car_tmp, &year_tmp,&price_tmp);
//		printf("%s %d %.2f\n", car_tmp, year_tmp, price_tmp);
//	}
//	fclose(f);
//}