#define _crt_secure_no_warnings
#include<stdio.h>
#include<stdlib.h>

struct NODE {
	int key;
	struct NODE* next;
};

struct NODE* createNewNode(int k) {
	struct NODE* newNode = (NODE*)malloc(sizeof(NODE));
	newNode->key = k;
	newNode->next = NULL;
	return newNode;
}
struct NODE* buildOneTwoThree() {
	NODE* first = createNewNode(1);
	NODE* second = createNewNode(2);
	NODE* third = createNewNode(3);
	first->next = second;
	second->next = third;
	return first;
}
int Length(NODE* start) {
	NODE* p = start;
	int count = 0;
	while (p != NULL) {
		count++;
		p = p->next;
	}
	return count;
}
void lengthTest() {
	NODE* myList = buildOneTwoThree();
	int len = Length(myList);
	printf("length : %d", len);
}
int main() {
	lengthTest();
	return 0;
}