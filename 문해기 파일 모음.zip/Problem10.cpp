//#define _CRT_SECURE_NO_WARNINGS
//#include<stdio.h>
//
//int main(){
//	FILE* f;
//	int n,k;
//	f = fopen("data.txt", "r");
//	while (fscanf(f, "%d", &n) != EOF) {
//		float sum = 0.0;
//		k = 0;
//		for (int i = 0;i < n;i++) {
//			fscanf(f, "%d", &k);
//			sum += k;
//		}
//		printf("Average : %f\n", sum / n);
//	}
//	fclose(f);
//}